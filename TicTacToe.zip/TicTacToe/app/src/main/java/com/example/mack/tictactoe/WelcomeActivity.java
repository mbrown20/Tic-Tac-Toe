package com.example.mack.tictactoe;

//Welcome Activity creates the welcome screen for users to enter in 2 names, read the
//instructions, and then proceed to play

//CPSC312-02
//PA4
//sources: https://stackoverflow.com/questions/9415629/want-to-make-random-imageview-as-unclickable
//<div>Icons made by <a href="https://www.flaticon.com/authors/twitter" title="Twitter">Twitter</a> from <a href="https://www.flaticon.com/" title="Flaticon">www.flaticon.com</a> is licensed by <a href="http://creativecommons.org/licenses/by/3.0/" title="Creative Commons BY 3.0" target="_blank">CC 3.0 BY</a></div>
//@author: Mackenzie Brown
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class WelcomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        //created button to play
        Button playButton = (Button) findViewById(R.id.buttonPlay);
    }
        //method for clicking playButton
        public void onButtonClicked(View view){

            //two users enter names
                EditText player1 = (EditText) findViewById(R.id.player1EditText);
                String player1Name = player1.getText().toString();

                EditText player2 = (EditText) findViewById(R.id.player2EditText);
                String player2Name = player2.getText().toString();

            //making sure the string isn't empty, otherwise they can't continue
                if(player1Name.equals("") | player2Name.equals("")){
                    Toast.makeText(this, "Please enter 2 names", Toast.LENGTH_LONG).show();

                }
                //Sends app to next activity with player entered information
                else {
                    Intent intent = new Intent(WelcomeActivity.this, GameActivity.class);
                    intent.putExtra("player1", player1Name);
                    intent.putExtra("player2", player2Name);
                    startActivity(intent);
                }

            }
    }

