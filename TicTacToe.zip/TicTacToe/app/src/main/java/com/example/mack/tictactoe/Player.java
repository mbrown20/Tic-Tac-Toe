package com.example.mack.tictactoe;

/**
 * This class keeps track of who the current player(symbol) is
 */
public class Player {
    char playerSymbol;

    //Creates a Player object to keep track of the current player
    //@param playerSymbol: current player symbol
    public Player(char playerSymbol) {
        this.playerSymbol = playerSymbol;
    }

    //getters and settings for changing and retriving the current player
    public char getPlayerSymbol() {
        return playerSymbol;
    }

    public void setPlayerSymbol(char playerSymbol) {
        this.playerSymbol = playerSymbol;
    }
}

