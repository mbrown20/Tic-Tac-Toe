package com.example.mack.tictactoe;

//This class plays a game of tic-tac-toe. It allows users to select an appropriate spot,
//complete a game, and then either exit or play again.
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class GameActivity extends AppCompatActivity {


    //global variables to be initialized in onCreate and used by onClick methods
    int currPlayer;
    int row;
    int col;
    char playerSymbol;
    Coordinates coord;
    TicTacToeBoard board;
    Player player;
    char oldSymbol;
    TextView commentary;
    int oldPlayer;
    String players[];
    ImageView currImage;
    Button quit;

    ImageView v00;
    ImageView v01;
    ImageView v02;
    ImageView v10;
    ImageView v11;
    ImageView v12;
    ImageView v20;
    ImageView v21;
    ImageView v22;
    Button playAgain;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        //get intent to retrieve extras
        Intent intent = getIntent();
        players = new String[2];
        //retrieve extras and place as player info in an array
        String player1 = intent.getStringExtra("player1");
        players[0]=player1;
        String player2 = intent.getStringExtra("player2");
        players[1]=player2;

        //select which player goes first
        Random rand = new Random();
        currPlayer = rand.nextInt(2);
        //starting icon information
        currImage= (ImageView) findViewById(R.id.imageViewCurrentPlayer);

        if (currPlayer == 1) {
            playerSymbol = 'X';
            currImage.setImageResource(R.drawable.rabbit);

        } else {
            playerSymbol = 'O';
            currImage.setImageResource(R.drawable.turtle);
        }
        player = new Player(playerSymbol);

        //display name of first player
        String goesFirst =  players[currPlayer]+" goes first!";
        commentary = (TextView) findViewById(R.id.textViewCurrentPlayer);
        commentary.setText(goesFirst);

        //initialize board and coordinate
        board = new TicTacToeBoard();
        coord = new Coordinates(0,0);

        //create imageViews as well as quit button
        quit = (Button) findViewById(R.id.buttonQuit);
        v00 = (ImageView) findViewById(R.id.imageView00);
        v01 = (ImageView) findViewById(R.id.imageView01);
        v02 = (ImageView) findViewById(R.id.imageView02);
        v10 = (ImageView) findViewById(R.id.imageView10);
        v11 = (ImageView) findViewById(R.id.imageView11);
        v12 = (ImageView) findViewById(R.id.imageView12);
        v20 = (ImageView) findViewById(R.id.imageView20);
        v21 = (ImageView) findViewById(R.id.imageView21);
        v22 = (ImageView) findViewById(R.id.imageView22);

        //create playAgain button, set to invisible
        playAgain = (Button) findViewById(R.id.buttonPlayAgain);
        playAgain.setVisibility(View.GONE);



    }


    //if someone wins or the board is full, imageViews can't be clicked and the playAgain button is visible
    public void noMorePlay(){
        v00.setClickable(false);
        v01.setClickable(false);
        v02.setClickable(false);
        v10.setClickable(false);
        v11.setClickable(false);
        v12.setClickable(false);
        v20.setClickable(false);
        v21.setClickable(false);
        v22.setClickable(false);
        playAgain.setVisibility(View.VISIBLE);


    }

    //if playAgain is clicked, restart activity
    public void onPlayAgainClicked(View view){
        Intent intent = getIntent();
        finish();
        startActivity(intent);
    }

    //button clicked method for the imageView at 0,0. All onButtonClicked methods for the 9 image view
    //are the same, but set different coordinates and set their own image.
    public void onButtonClicked00(View view) {
            row = 0;
            col = 0;
        //set the row and column to the coordinate of this imageView
            coord.setCol(col);
            coord.setRow(row);
        //check for valid move, otherwise toast message
            if (board.isValidMove(coord) == false) {
                Toast.makeText(this, "Not a valid move", Toast.LENGTH_LONG).show();
                //otherwise let the user play
            } else if (board.isValidMove(coord) == true) {
                board.makeMove(coord, player.getPlayerSymbol());
                //depending on which player, set the appropriate image
                if (currPlayer == 0) {
                    v00.setImageResource(R.drawable.turtle);
                    //if that user won, display a message and stop the clickability of each icon
                    if(board.Winner('O')==true){
                        commentary.setText(players[currPlayer]+" is the winner! Play Again?");
                        noMorePlay();
                    }
                    else if(board.isFull()){
                        commentary.setText("Scratch game");
                        noMorePlay();
                    }
                    //otherwise, change the player and the instruction to tell the users who's turn it is
                    else {
                        commentary.setText(players[1] + "'s Turn.");
                        currImage.setImageResource(R.drawable.rabbit);

                        oldPlayer = 0;
                        currPlayer = 1;
                        oldSymbol = player.getPlayerSymbol();
                        player.setPlayerSymbol('X');
                    }
                } else {
                    //same as before but in case of other player
                    v00.setImageResource(R.drawable.rabbit);
                    if(board.Winner('X')==true){
                        commentary.setText(players[currPlayer]+" is the winner! Play Again?");
                        noMorePlay();
                    }
                    else if(board.isFull()){
                        commentary.setText("Scratch game");
                        noMorePlay();
                    }
                    else {
                        commentary.setText(players[0] + "'s Turn.");
                        currImage.setImageResource(R.drawable.turtle);

                        oldPlayer = 1;
                        currPlayer = 0;
                        oldSymbol = player.getPlayerSymbol();
                        player.setPlayerSymbol('O');
                    }
                }



            }

        }

        //onClick method for imageView at 0,1

        public void onButtonClicked01(View view){

            row = 0;
            col=1;
            coord.setCol(col);
            coord.setRow(row);

            if (board.isValidMove(coord) == false) {
                Toast.makeText(this, "Not a valid move", Toast.LENGTH_LONG).show(); //THIS DOES WORK!!
            } else if (board.isValidMove(coord) == true) {
                board.makeMove(coord, player.getPlayerSymbol());
                if (currPlayer == 0) {
                    v01.setImageResource(R.drawable.turtle);
                    if(board.Winner(player.getPlayerSymbol())==true){
                        commentary.setText(players[currPlayer]+" is the winner! Play Again?");
                        noMorePlay();

                    }
                    else if(board.isFull()){
                        commentary.setText("Scratch game");
                        noMorePlay();
                    }
                    else {
                        commentary.setText(players[1] + "'s Turn.");
                        currImage.setImageResource(R.drawable.rabbit);

                        oldPlayer = 0;
                        currPlayer = 1;
                        oldSymbol = player.getPlayerSymbol();
                        player.setPlayerSymbol('X');
                    }
                } else {
                    v01.setImageResource(R.drawable.rabbit);
                    if(board.Winner(player.getPlayerSymbol())==true){
                        commentary.setText(players[currPlayer]+" is the winner! Play Again?");
                        noMorePlay();
                    }
                    else if(board.isFull()){
                        commentary.setText("Scratch game");
                        noMorePlay();
                    }
                    else {
                        commentary.setText(players[0] + "'s Turn.");
                        currImage.setImageResource(R.drawable.turtle);

                        oldPlayer = 1;
                        currPlayer = 0;
                        oldSymbol = player.getPlayerSymbol();
                        player.setPlayerSymbol('O');
                    }
                }



            }


        }
    //onClick method for imageView at 0,2

    public void onButtonClicked02(View view){
            row = 0;
            col=2;
            coord.setCol(col);
            coord.setRow(row);
            if (board.isValidMove(coord) == false) {
                Toast.makeText(this, "Not a valid move", Toast.LENGTH_LONG).show(); //THIS DOES WORK!!
            } else if (board.isValidMove(coord) == true) {
                board.makeMove(coord, player.getPlayerSymbol());
                if (currPlayer == 0) {
                    v02.setImageResource(R.drawable.turtle);
                    if(board.Winner(player.getPlayerSymbol())==true){
                        commentary.setText(players[currPlayer]+" is the winner! Play Again?");
                        noMorePlay();
                    }
                    else if(board.isFull()){
                        commentary.setText("Scratch game");
                        noMorePlay();
                    }
                    else {
                        commentary.setText(players[1] + "'s Turn.");
                        currImage.setImageResource(R.drawable.rabbit);

                        oldPlayer = 0;
                        currPlayer = 1;
                        oldSymbol = player.getPlayerSymbol();
                        player.setPlayerSymbol('X');
                    }
                } else {
                    v02.setImageResource(R.drawable.rabbit);
                    if(board.Winner(player.getPlayerSymbol())==true){
                        commentary.setText(players[currPlayer]+" is the winner! Play Again?");
                        noMorePlay();
                    }
                    else if(board.isFull()){
                        commentary.setText("Scratch game");
                        noMorePlay();
                    }
                    else {
                        commentary.setText(players[0] + "'s Turn.");
                        currImage.setImageResource(R.drawable.turtle);

                        oldPlayer = 1;
                        currPlayer = 0;
                        oldSymbol = player.getPlayerSymbol();
                        player.setPlayerSymbol('O');
                    }
                }



            }

        }

    //onClick method for imageView at 1,0

    public void onButtonClicked10(View view){
            row = 1;
            col=0;
            coord.setCol(col);
            coord.setRow(row);
            if (board.isValidMove(coord) == false) {
                Toast.makeText(this, "Not a valid move", Toast.LENGTH_LONG).show(); //THIS DOES WORK!!
            } else if (board.isValidMove(coord) == true) {
                board.makeMove(coord, player.getPlayerSymbol());
                if (currPlayer == 0) {
                    v10.setImageResource(R.drawable.turtle);
                    if(board.Winner(player.getPlayerSymbol())==true){
                        commentary.setText(players[currPlayer]+" is the winner! Play Again?");
                        noMorePlay();
                    }
                    else if(board.isFull()){
                        commentary.setText("Scratch game");
                        noMorePlay();
                    }
                    else {
                        commentary.setText(players[1] + "'s Turn.");
                        currImage.setImageResource(R.drawable.rabbit);

                        oldPlayer = 0;
                        currPlayer = 1;
                        oldSymbol = player.getPlayerSymbol();
                        player.setPlayerSymbol('X');
                    }
                } else {
                    v10.setImageResource(R.drawable.rabbit);
                    if(board.Winner(player.getPlayerSymbol())==true){
                        commentary.setText(players[currPlayer]+" is the winner! Play Again?");
                        noMorePlay();
                    }
                    else if(board.isFull()){
                        commentary.setText("Scratch game");
                        noMorePlay();
                    }
                    else {
                        commentary.setText(players[0] + "'s Turn.");
                        currImage.setImageResource(R.drawable.turtle);

                        oldPlayer = 1;
                        currPlayer = 0;
                        oldSymbol = player.getPlayerSymbol();
                        player.setPlayerSymbol('O');
                    }
                }



            }
        }
    //onClick method for imageView at 1,1

        public void onButtonClicked11(View view){
            row = 1;
            col=1;
            coord.setCol(col);
            coord.setRow(row);
            if (board.isValidMove(coord) == false) {
                Toast.makeText(this, "Not a valid move", Toast.LENGTH_LONG).show(); //THIS DOES WORK!!
            } else if (board.isValidMove(coord) == true) {
                board.makeMove(coord, player.getPlayerSymbol());
                if (currPlayer == 0) {
                    v11.setImageResource(R.drawable.turtle);
                    if(board.Winner(player.getPlayerSymbol())==true){
                        commentary.setText(players[currPlayer]+" is the winner! Play Again?");
                        noMorePlay();
                    }
                    else if(board.isFull()){
                        commentary.setText("Scratch game");
                        noMorePlay();
                    }
                    else {
                        commentary.setText(players[1] + "'s Turn.");
                        currImage.setImageResource(R.drawable.rabbit);

                        oldPlayer = 0;
                        currPlayer = 1;
                        oldSymbol = player.getPlayerSymbol();
                        player.setPlayerSymbol('X');
                    }
                } else {
                    v11.setImageResource(R.drawable.rabbit);
                    if(board.Winner(player.getPlayerSymbol())==true){
                        commentary.setText(players[currPlayer]+" is the winner! Play Again?");
                        noMorePlay();
                    }
                    else if(board.isFull()){
                        commentary.setText("Scratch game");
                        noMorePlay();
                    }
                    else {
                        commentary.setText(players[0] + "'s Turn.");
                        currImage.setImageResource(R.drawable.turtle);

                        oldPlayer = 1;
                        currPlayer = 0;
                        oldSymbol = player.getPlayerSymbol();
                        player.setPlayerSymbol('O');
                    }
                }



            }


        }
    //onClick method for imageView at 1,2

    public void onButtonClicked12(View view){
            row = 1;
            col=2;
            coord.setCol(col);
            coord.setRow(row);
            if (board.isValidMove(coord) == false) {
                Toast.makeText(this, "Not a valid move", Toast.LENGTH_LONG).show(); //THIS DOES WORK!!
            } else if (board.isValidMove(coord) == true) {
                board.makeMove(coord, player.getPlayerSymbol());
                if (currPlayer == 0) {
                    v12.setImageResource(R.drawable.turtle);
                    if(board.Winner(player.getPlayerSymbol())==true){
                        commentary.setText(players[currPlayer]+" is the winner! Play Again?");
                        noMorePlay();
                    }
                    else if(board.isFull()){
                        commentary.setText("Scratch game");
                        noMorePlay();
                    }
                    else {
                        commentary.setText(players[1] + "'s Turn.");
                        currImage.setImageResource(R.drawable.rabbit);

                        oldPlayer = 0;
                        currPlayer = 1;
                        oldSymbol = player.getPlayerSymbol();
                        player.setPlayerSymbol('X');
                    }
                } else {
                    v12.setImageResource(R.drawable.rabbit);
                    if(board.Winner(player.getPlayerSymbol())==true){
                        commentary.setText(players[currPlayer]+" is the winner! Play Again?");
                        noMorePlay();
                    }
                    else if(board.isFull()){
                        commentary.setText("Scratch game");
                        noMorePlay();
                    }
                    else {
                        commentary.setText(players[0] + "'s Turn.");
                        currImage.setImageResource(R.drawable.turtle);

                        oldPlayer = 1;
                        currPlayer = 0;
                        oldSymbol = player.getPlayerSymbol();
                        player.setPlayerSymbol('O');
                    }
                }



            }


        }
    //onClick method for imageView at 2,0

    public void onButtonClicked20(View view){
            row = 2;
            col=0;
            coord.setCol(col);
            coord.setRow(row);
            if (board.isValidMove(coord) == false) {
                Toast.makeText(this, "Not a valid move", Toast.LENGTH_LONG).show(); //THIS DOES WORK!!
            } else if (board.isValidMove(coord) == true) {
                board.makeMove(coord, player.getPlayerSymbol());
                if (currPlayer == 0) {
                    v20.setImageResource(R.drawable.turtle);
                    if(board.Winner(player.getPlayerSymbol())==true){
                        commentary.setText(players[currPlayer]+" is the winner! Play Again?");
                        noMorePlay();
                    }
                    else if(board.isFull()){
                        commentary.setText("Scratch game");
                        noMorePlay();
                    }
                    else {
                        commentary.setText(players[1] + "'s Turn.");
                        currImage.setImageResource(R.drawable.rabbit);

                        oldPlayer = 0;
                        currPlayer = 1;
                        oldSymbol = player.getPlayerSymbol();
                        player.setPlayerSymbol('X');
                    }
                } else {
                    v20.setImageResource(R.drawable.rabbit);
                    if(board.Winner(player.getPlayerSymbol())==true){
                        commentary.setText(players[currPlayer]+" is the winner! Play Again?");
                        noMorePlay();
                    }
                    else if(board.isFull()){
                        commentary.setText("Scratch game");
                        noMorePlay();
                    }
                    else {
                        commentary.setText(players[0] + "'s Turn.");
                        currImage.setImageResource(R.drawable.turtle);

                        oldPlayer = 1;
                        currPlayer = 0;
                        oldSymbol = player.getPlayerSymbol();
                        player.setPlayerSymbol('O');
                    }
                }



            }


        }
    //onClick method for imageView at 2,1


    public void onButtonClicked21(View view){
            row = 2;
            col=1;
            coord.setCol(col);
            coord.setRow(row);
            if (board.isValidMove(coord) == false) {
                Toast.makeText(this, "Not a valid move", Toast.LENGTH_LONG).show(); //THIS DOES WORK!!
            } else if (board.isValidMove(coord) == true) {
                board.makeMove(coord, player.getPlayerSymbol());
                if (currPlayer == 0) {
                    v21.setImageResource(R.drawable.turtle);
                    if(board.Winner(player.getPlayerSymbol())==true){
                        commentary.setText(players[currPlayer]+" is the winner! Play Again?");
                        noMorePlay();
                    }
                    else if(board.isFull()){
                        commentary.setText("Scratch game");
                        noMorePlay();
                    }
                    else {
                        commentary.setText(players[1] + "'s Turn.");
                        currImage.setImageResource(R.drawable.rabbit);

                        oldPlayer = 0;
                        currPlayer = 1;
                        oldSymbol = player.getPlayerSymbol();
                        player.setPlayerSymbol('X');
                    }
                } else {
                    v21.setImageResource(R.drawable.rabbit);
                    if(board.Winner(player.getPlayerSymbol())==true){
                        commentary.setText(players[currPlayer]+" is the winner! Play Again?");
                        noMorePlay();
                    }
                    else if(board.isFull()){
                        commentary.setText("Scratch game");
                        noMorePlay();
                    }
                    else {
                        commentary.setText(players[0] + "'s Turn.");
                        currImage.setImageResource(R.drawable.turtle);

                        oldPlayer = 1;
                        currPlayer = 0;
                        oldSymbol = player.getPlayerSymbol();
                        player.setPlayerSymbol('O');
                    }
                }



            }
        }
    //onClick method for imageView at 2,2

    public void onButtonClicked22(View view){
            row = 2;
            col=2;
            coord.setCol(col);
            coord.setRow(row);
            if (board.isValidMove(coord) == false) {
                Toast.makeText(this, "Not a valid move", Toast.LENGTH_LONG).show(); //THIS DOES WORK!!
            } else if (board.isValidMove(coord) == true) {
                board.makeMove(coord, player.getPlayerSymbol());
                if (currPlayer == 0) {
                    v22.setImageResource(R.drawable.turtle);
                    if(board.Winner(player.getPlayerSymbol())==true){
                        commentary.setText(players[currPlayer]+" is the winner! Play Again?");
                        noMorePlay();
                    }
                    else if(board.isFull()){
                        commentary.setText("Scratch game");
                        noMorePlay();
                    }
                    else {
                        commentary.setText(players[1] + "'s Turn.");
                        currImage.setImageResource(R.drawable.rabbit);

                        oldPlayer = 0;
                        currPlayer = 1;
                        oldSymbol = player.getPlayerSymbol();
                        player.setPlayerSymbol('X');
                    }
                } else {
                    v22.setImageResource(R.drawable.rabbit);
                    if(board.Winner(player.getPlayerSymbol())==true){
                        commentary.setText(players[currPlayer]+" is the winner! Play Again?");
                        noMorePlay();
                    }
                    else if(board.isFull()){
                        commentary.setText("Scratch game");
                        noMorePlay();
                    }
                    else {
                        commentary.setText(players[0] + "'s Turn.");
                        currImage.setImageResource(R.drawable.turtle);

                        oldPlayer = 1;
                        currPlayer = 0;
                        oldSymbol = player.getPlayerSymbol();
                        player.setPlayerSymbol('O');
                    }
                }



            }



        }
        //onButtonClicked method for the exit button, sends the activity back to welcomeActivity

        public void onExitButtonClicked(View view){
            Intent intent = new Intent(GameActivity.this, WelcomeActivity.class);
            startActivity(intent);
        }




}
