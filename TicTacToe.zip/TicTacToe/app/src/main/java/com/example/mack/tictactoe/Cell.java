package com.example.mack.tictactoe;

/**
 * This class creates a cell object which contains a character
 */
public class Cell {
    char symbol;
    Coordinates coordinate;

    //Creates a cell object containing a character
    //@param row, col: location of the cell in the grid
    //@param symbol: the character in the cell
    public Cell(int row, int col, char symbol){
        coordinate = new Coordinates(row, col);
        this.symbol = symbol;


    }
    //@param symbol: sets the current contents of the cell to this symbol
    public void setSymbol(char symbol){
        this.symbol = symbol;
    }
    //@return symbol: return the cell's contents
    public char getSymbol(){
        return this.symbol;
    }
}
