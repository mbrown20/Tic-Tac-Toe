package com.example.mack.tictactoe;
//<div>Icons made by <a href="https://www.flaticon.com/authors/twitter" title="Twitter">Twitter</a> from <a href="https://www.flaticon.com/" title="Flaticon">www.flaticon.com</a> is licensed by <a href="http://creativecommons.org/licenses/by/3.0/" title="Creative Commons BY 3.0" target="_blank">CC 3.0 BY</a></div>
/**
 * This program creates a game of Tic Tac Toe in which two players can play
 * a game (or multiple games) on a grid size of their choosing
 * CPSC 312-02, Fall 2017
 * Programming Assignment #1
 * No sources to cite
 *
 * @author Mackenzie Brown
 * @version v1.0 09/13/17
 */

import android.media.Image;
import android.widget.ImageView;

import java.util.Scanner;
import java.util.Random;

import static android.support.v7.appcompat.R.styleable.View;


/**
 * This class plays one full game of Tic Tac Toe and allows a user to play more games if they want
 */
public class Play {

}
