package com.example.mack.tictactoe;

/**
 * This class takes a row and a column and turns them into a coordinate object
 */
public class Coordinates {
    int row;
    int col;

    //creates coordinate object using row and column
    //@param row, col: user entered information about where they want to play
    public Coordinates(int row, int col) {
        this.row = row;
        this.col = col;
    }
    //toString representation with parenthesis, comma
    //@return the coordinate representation of the spot (a, b)
    public String toString() {
        String coord;
        coord = "(" + row + "," + col + ")";
        return coord;
    }
    //getters and setters for retreiving/setting the rows and columns
    //after the user enters them each turn
    public int getRow() {
        return row;
    }

    public void setRow(int row) {
        this.row = row;
    }

    public int getCol() {
        return col;
    }

    public void setCol(int col) {
        this.col = col;
    }




}