package com.example.mack.tictactoe;

/**
 * This class is just to retrieve the win/loss stats for each player
 * and contains functions for determining other stats
 */
public class GameStats {
    int win;
    int loss;
    double percent;
    int scratch;
    int games;

    //allows for two instances of GameStats(one for each player)
    public GameStats() {
    }
    //keeps track of wins/losses for both players
    public int getWin() {
        return win;
    }

    public void setWin(int win) {
        this.win = win;
    }

    public int getLoss() {
        return loss;
    }

    public void setLoss(int loss) {
        this.loss = loss;
    }

    //keeps track of scratch games
    public void setScratch(int scratch){
        this.scratch = scratch;
    }

    public int getScratch(){
        System.out.println("Scratch games: "+this.scratch);
        return scratch;
    }

    //sets up win loss ratio
    public void winLossRatio(int win, int loss){
        System.out.println("Win to loss ratio: "+win +":"+loss);
    }

    //calculates win percentage to two decimal places
    //@param win, games: individual user wins and all games
    public void calculatePercentage(int win, int games) {
        double percentage = win * 100.0f / games;
        System.out.print("Win percentage: ");
        System.out.printf("%.2f", percentage);
        System.out.print("%");

    }


}
