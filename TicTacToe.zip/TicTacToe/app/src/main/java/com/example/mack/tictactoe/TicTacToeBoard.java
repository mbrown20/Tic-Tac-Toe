package com.example.mack.tictactoe;

import java.util.Scanner;
/**
 * This class is where most of the gameplay turns to. It essentially makes all
 * necessary changes to the board. Additionally is uses boolean methods to
 * check the current state of the board
 */
public class TicTacToeBoard {
    Cell[][]grid;

    //creates empty board of size n with the blank char ('-')
    //@param n: user entered size of the board
    public TicTacToeBoard(){
        grid = new Cell[3][3];
        for (int i = 0; i < 3; i++){
            for (int j = 0; j < 3; j++){
                grid[i][j] = new Cell(i, j, '-');
            }
        }
    }



    public Cell[][] getGrid() {
        return grid;
    }

    //checks to see if board is full (for sake of scratch game)
    //@param n: user entered size of the board
    //@return boolean: returns true if the board isFull, false if there is room
    public boolean isFull(){
        for (int i = 0; i< 3; i++){
            for (int j = 0; j<3; j++){
                if (grid[i][j].getSymbol() == '-'){
                    return false;
                }
            }
        }
        System.out.println("Scratch game!");
        return true;
    }

    //changes blank spot on board to the symbol of the player making the move
    //@param cordinate, playerSymbol: takes in the lccation
    //to be played, and the symbol that should be played there
    public void makeMove(Coordinates coordinate, char playerSymbol){
        grid[coordinate.getRow()][coordinate.getCol()].setSymbol(playerSymbol);
    }

    //determines if there is a winning row, column, or horizontal on the board
    //@param playerSymbol: takes in the last played symbol to see if
    //that player made a move that warrants a win
    //@return boolean: returns true if someone won, false otherwise

    public boolean Winner(char playerSymbol){
        int symbolCount;

        //horizontal win
        for (int row = 0; row<3; row++){
            symbolCount = 0;


            for (int col = 0; col<3; col++) {
                if (grid[row][col].getSymbol()==playerSymbol){
                    symbolCount++;
                    if (symbolCount == 3){
                        System.out.println("Player " +playerSymbol+" is a winner!");
                        return true;
                    }

                }


            }
        }
//vertical win
        for (int col = 0; col<3; col++){
            symbolCount = 0;

            for (int row = 0; row<3; row++) {
                if (grid[row][col].getSymbol()==playerSymbol){
                    symbolCount++;
                    if (symbolCount == 3){
                        System.out.println("Player "+playerSymbol+" is a winner!");
                        return true;
                    }

                }

            }
        }

        //top left to bottom right
        symbolCount = 0;
        int row = 0;
        for (int col = 0; col<3; col++){
            if (grid[row][col].getSymbol()==playerSymbol) {
                symbolCount++;
                row++;
                if (symbolCount == 3) {
                    System.out.println("Player "+playerSymbol+" is a winner!");
                    return true;
                }


            }



        }

        symbolCount = 0;
        row = 0;
        for (int col = 3-1; col>=0; col--){
            if (grid[row][col].getSymbol()==playerSymbol) {
                symbolCount++;
                row++;
                if (symbolCount == 3) {
                    System.out.println("Player "+playerSymbol+" is a winner!");
                    return true;
                }


            }



        }
        return false;
    }



    //determines if an attempt at placing a symbol on the board is valid
    //(if the spot is already taken the user must pick something else)
    public boolean isValidMove(Coordinates coordinate){
        int col = coordinate.getCol();
        int row = coordinate.getRow();
        if((grid[row][col].getSymbol()=='X') || grid[row][col].getSymbol()=='O'){
            return false;
        }
        else
            return true;

    }
    //toString to print out the board (with row and column numbers)
    @Override
    public String toString(){
        System.out.print("   ");
        for (int k = 0; k < 3; k++){
            System.out.print(k+"  ");
        }
        String printBoard="";
        int colNums = 0;
        System.out.println();
        for (int i = 0; i < 3; i++){
            printBoard += i+ "  ";
            for (int j = 0; j < 3; j++){
                printBoard = printBoard + grid[i][j].getSymbol()+ "  ";
            }
            printBoard = printBoard + "\n";
        }
        return printBoard;
    }


}
